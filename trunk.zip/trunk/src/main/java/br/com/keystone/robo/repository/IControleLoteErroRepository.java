package br.com.keystone.robo.repository;

import br.com.keystone.robo.model.ControleLoteErro;

public interface IControleLoteErroRepository {

	public void inserirErro(ControleLoteErro controleLoteErro);
}