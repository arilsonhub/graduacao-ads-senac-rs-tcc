package br.com.keystone.robo.vo;

import java.util.List;

public class ListCampanhaVO {
	
	private List<CampanhaVO> list;

	public List<CampanhaVO> getList() {
		return list;
	}

	public void setList(List<CampanhaVO> list) {
		this.list = list;
	}    
}