package br.com.keystone.robo.core.exceptions;

public class IntranetException extends Exception {
	
	private static final long serialVersionUID = 4626284680443865492L;

	public IntranetException(String msg){
		super(msg);
	}
}