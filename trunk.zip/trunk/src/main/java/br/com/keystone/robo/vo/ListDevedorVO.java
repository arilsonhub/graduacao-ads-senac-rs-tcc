package br.com.keystone.robo.vo;

import java.util.List;

import br.com.keystone.robo.model.Devedor;

public class ListDevedorVO {

	private List<Devedor> list;

	public List<Devedor> getList() {
		return list;
	}

	public void setList(List<Devedor> list) {
		this.list = list;
	}
}